# -*- coding: utf-8 -*-
"""
core/contracts.py — Contratos (dataclasses) partilhados entre camadas.

Estes tipos definem as interfaces entre as camadas da arquitetura:
  - Signal:     saída do SignalEngine (o que o modelo/heurística sugere)
  - Action:     saída do PositionManager (o que fazer com a posição)
  - ExitSignal: saída do PositionManager quando uma posição fecha
  - RiskDecision: saída do RiskManager (pode ou não abrir)
  - Position:   estado de uma posição aberta

Nenhuma lógica de negócio aqui — apenas tipos.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Signal:
    """Sinal produzido pelo SignalEngine a partir de features."""
    lado: str            # 'C' (compra), 'V' (venda), '' (neutro)
    score: float         # 0.0 a 1.0
    confianca: float     # EWMA do score
    motivos: list[str]   # Razões textuais do sinal
    contrib: dict        # Contribuição por feature {feature: peso}
    horizonte: int       # Horizonte em segundos


@dataclass
class Action:
    """Decisão do PositionManager sobre o que fazer."""
    tipo: str            # 'ABRIR', 'FECHAR', 'MANTER'
    lado: str            # 'C', 'V'
    preco: float
    tp: float            # Take-profit
    sl: float            # Stop-loss
    motivo: str


@dataclass
class ExitSignal:
    """Sinal de saída de uma posição."""
    preco: float
    motivo: str          # 'TP', 'SL', 'REVERSAO', 'TEMPO', 'SHUTDOWN'
    pnl: float
    holding_s: float     # Tempo em posição (segundos)


@dataclass
class RiskDecision:
    """Resposta do RiskManager sobre permissão de abrir posição."""
    permitido: bool
    motivo: str          # 'OK', 'COOLDOWN', 'CIRCUIT_BREAKER', 'FORA_HORARIO', 'DRAWDOWN'
    cooldown_restante: float  # Segundos até poder operar (0 se permitido)


@dataclass
class Position:
    """Estado de uma posição aberta."""
    lado: str            # 'C', 'V'
    preco_entrada: float
    tp: float
    sl: float
    aberta_em: float     # Timestamp epoch
    regime_abertura: Optional[str] = None
    stop_preco: Optional[float] = None  # Trailing stop
    breakeven: bool = False

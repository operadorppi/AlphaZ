# -*- coding: utf-8 -*-
"""
core/risk_manager.py — Gestão de Risco e Política de Execução.

Responsável por validar sinais do modelo contra limites operacionais:
  - Threshold de confiança
  - Limite de perda diária
  - Horários proibidos
  - Exposição máxima
"""

import logging
from datetime import datetime

log = logging.getLogger('risk')

class RiskManager:
    def __init__(self, config=None):
        self.config = config or {}
        self.threshold = self.config.get('ml_threshold', 0.60)
        self.max_posicao = self.config.get('max_posicao', 5)
        self.stop_diario = self.config.get('stop_diario', -1000)
        self.base_size = self.config.get('base_size', 1)
        self.lucro_acumulado = 0.0

    def avaliar_sinal(self, ativo, probabilidade, volatilidade_bps=None, regime=None):
        """
        Transforma probabilidade bruta em ação operacional.
        Retorna: (int acao, float prob, str motivo, int size, float tp, float sl)
        """
        # 1. Filtro de Confiança
        if probabilidade >= self.threshold:
            acao = 1
        elif probabilidade <= (1 - self.threshold):
            acao = -1
        else:
            return 0, probabilidade, "NEUTRO_THRESHOLD", 0, 0, 0

        # 2. Filtro de Risco Diário
        if self.lucro_acumulado <= self.stop_diario:
            log.warning(f"[RISK] Bloqueio por Stop Diário atingido: {self.lucro_acumulado}")
            return 0, probabilidade, "BLOQUEIO_STOP_DIARIO", 0, 0, 0

        # 3. Filtro de Horário
        agora = datetime.now().time()
        if agora > datetime.strptime("17:30", "%H:%M").time():
            return 0, probabilidade, "HORARIO_ENCERRADO", 0, 0, 0

        # 4. Sizing por Confiança (Linear scaling entre threshold e 1.0)
        confianca_relativa = (abs(probabilidade - 0.5) * 2 - (self.threshold - 0.5) * 2) / (1 - (self.threshold - 0.5) * 2)
        confianca_relativa = max(0, min(1, confianca_relativa))
        size = int(self.base_size + (self.max_posicao - self.base_size) * confianca_relativa)

        # 5. TP/SL Adaptativo por Volatilidade
        tp, sl = self.calcular_barreiras_dinamicas(ativo, volatilidade_bps, regime)

        return acao, probabilidade, "VALIDADO", size, tp, sl

    def calcular_barreiras_dinamicas(self, ativo, vol_bps, regime):
        """Calcula TP/SL adaptativos. Se vol não informada, usa defaults."""
        tp_base = self.config.get('trading', {}).get('tp_pts', 100)
        sl_base = self.config.get('trading', {}).get('sl_pts', 50)
        
        if not vol_bps or vol_bps <= 0:
            return tp_base, sl_base

        # Ajuste por Volatilidade: Multiplicador baseado em desvio da vol média (ex: 20 bps)
        mult_vol = vol_bps / 20.0
        tp = tp_base * max(0.8, min(2.0, mult_vol))
        sl = sl_base * max(0.8, min(2.0, mult_vol))

        # Ajuste por Regime
        if regime in ['tendencia_alta', 'tendencia_baixa']:
            tp *= 1.2  # Deixa correr na tendência
        elif regime == 'lateral':
            tp *= 0.8  # Alvo mais curto em lateral

        return round(tp, 1), round(sl, 1)

    def registrar_resultado(self, pnl):
        self.lucro_acumulado += pnl
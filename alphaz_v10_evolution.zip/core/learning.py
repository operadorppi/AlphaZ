# -*- coding: utf-8 -*-
"""
core/learning.py — Aprendizado de pesos por MFE/MAE.

Extrai de Analise:
  - aprender_mfe_mae (linha 2861)
  - _recalc_acuracia (linha 2931)
  - carregar_aprendizado (linha 1726)
  - salvar_aprendizado (linha 1726)
  - resultados, previsoes, feature_hits, pesos
"""

import json
import logging
from pathlib import Path
from datetime import datetime

log = logging.getLogger(__name__)

PESOS_INICIAIS = {
    'preco_andando': 0.3, 'eficiencia': 0.20, 'aceleracao': 0.2,
    'persistencia': 0.15, 'inst_lidera': 0.2, 'varejo_contra': -0.25,
    'book_imb': 0.2, 'defesa': 0.20, 'absorcao_book': -0.30,
    'retirada': -0.2, 'reposicao': 0.2, 'thinning': -0.2,
    'layering': -0.1, 'delta_book': 0.20,
    'cross_asset': 0.25, 'cross_asset_preco': 0.1,
    'liquidez_removida': -0.4, 'stop_hunt': 0.2,
    'horario_inst': 0.3, 'horario_varejo': -0.3,
    'range': 0.3,
    'absorcao_preco': 0.3,
    'corretora_tt_book': 0.4,
    'acumulacao': 0.5,
    'ofi': 0.45,
    'ofi_ewma': 0.25,
    'book_level_spread': 0.15,
    'book_imb_l1': 0.25, 'book_imb_l10': 0.30, 'book_microprice': 0.15, 'book_hhi': 0.10,
    'micro_drift': 0.35,
    'imb_ponderado': 0.35,
    'slope_book': 0.25,
    'trade_metrics': 0.25,
    'cross_lag': 0.35,
    'cvd_div': 0.50,
    'vp_vp_total': 0.60,
    'vpin': 0.40,
    'kyle_lambda': 0.30
}


class Learning:
    """Estado de aprendizado: pesos, feature_hits, acuracia."""

    def __init__(self, config=None):
        self.config = config or {}
        self.pesos = dict(PESOS_INICIAIS)
        self.pesos_regime = {
            'tendencia_alta': dict(PESOS_INICIAIS),
            'tendencia_baixa': dict(PESOS_INICIAIS),
            'lateral': dict(PESOS_INICIAIS),
            'vol_alta': dict(PESOS_INICIAIS),
            'vol_baixa': dict(PESOS_INICIAIS),
            'tendencia_alta_vol_alta': dict(PESOS_INICIAIS),
            'tendencia_alta_vol_baixa': dict(PESOS_INICIAIS),
            'tendencia_baixa_vol_alta': dict(PESOS_INICIAIS),
            'tendencia_baixa_vol_baixa': dict(PESOS_INICIAIS),
            'lateral_vol_alta': dict(PESOS_INICIAIS),
            'lateral_vol_baixa': dict(PESOS_INICIAIS),
        }
        from collections import deque
        self.feature_hits = {}
        self.acuracia = {}
        self.resultados = deque(maxlen=5000)
        self.previsoes = deque(maxlen=5000)
        # Feature death: features que sistematicamente pioram o resultado
        # tem peso zerado e deixam de contribuir no scoring.
        self.morto = set()

        # Boost de OFI em regimes
        self.pesos_regime['tendencia_alta']['ofi'] = 0.6
        self.pesos_regime['tendencia_alta']['ofi_ewma'] = 0.4
        self.pesos_regime['tendencia_baixa']['ofi'] = 0.6
        self.pesos_regime['tendencia_baixa']['ofi_ewma'] = 0.4
        self.pesos_regime['vol_alta']['ofi'] = 0.5
        self.pesos_regime['vol_alta']['ofi_ewma'] = 0.35
        self.pesos_regime['lateral']['ofi'] = 0.15
        self.pesos_regime['lateral']['ofi_ewma'] = 0.1

    def aprender_mfe_mae(self, contrib, acertou, mfe, mae, regime_abertura=None):
        """Ajusta pesos por MFE/MAE com decay."""
        if not contrib:
            return
        decay = self.config.get('aprendizado_decay', 0.95)
        regime_nome = regime_abertura or 'lateral'

        for key, _ in contrib:
            if key in self.morto:
                self.pesos[key] = 0.0
                continue  # feature morta permanece zerada
            inicial = PESOS_INICIAIS.get(key, 0.0)
            floor = abs(inicial) * 0.3
            atual = self.pesos.get(key, 0.0)
            self.pesos[key] = max(abs(atual) * decay, floor) * (1 if atual >= 0 else -1)
            if regime_nome in self.pesos_regime:
                atual_r = self.pesos_regime[regime_nome].get(key, 0.0)
                self.pesos_regime[regime_nome][key] = max(abs(atual_r) * decay, floor) * (1 if atual_r >= 0 else -1)

        qualidade_trade = (mfe / max(abs(mae), 1.0)) if mae != 0 else 2.0

        for key, mult in contrib:
            if key in self.morto:
                continue  # feature morta não re-aprende
            h = self.feature_hits.setdefault(key, {'acertos': 0, 'erros': 0})
            amostras_previas = h['acertos'] + h['erros']
            min_amostras = self.config.get('aprendizado_min_amostras', 20)
            fator_confianca = min(1.0, amostras_previas / min_amostras) if amostras_previas else 0.2
            peso_atual = self.pesos.get(key, 0.0)

            if acertou:
                alvo = 1.0 if mult >= 0 else -1.0
            else:
                alvo = -1.0 if mult >= 0 else 1.0

            delta = self.config.get('aprendizado_delta', 0.05)
            ajuste = delta * min(qualidade_trade, 2.0) * fator_confianca
            novo_peso = peso_atual + (alvo - peso_atual) * ajuste
            self.pesos[key] = max(-1.0, min(1.0, novo_peso))
            h['acertos' if acertou else 'erros'] += 1

        self._recalc_acuracia()
        self._verificar_feature_death()

    def _verificar_feature_death(self):
        """Feature death: zera o peso de features persistentemente inuteis.

        Feature com amostras suficientes e acuracia abaixo de um limiar
        deixa de contribuir (peso = 0), evitando que continuem poluindo o
        score indefinidamente apos o decay estacionar no floor positivo.
        """
        min_amostras = self.config.get('aprendizado_morte_min_amostras', 40)
        limiar = self.config.get('aprendizado_morte_acuracia', 0.4)
        for key in list(self.feature_hits.keys()):
            if key in self.morto:
                continue
            h = self.feature_hits[key]
            total = h['acertos'] + h['erros']
            if total < min_amostras:
                continue
            acuracia = h['acertos'] / total
            if acuracia < limiar:
                self.morto.add(key)
                self.pesos[key] = 0.0
                self.pesos_regime = {
                    r: dict({**w, key: 0.0} if key in w else w)
                    for r, w in self.pesos_regime.items()
                }
                log.warning("[FEATURE-DEATH] feature %s zerada (acc=%.3f, n=%d)",
                            key, acuracia, total)

    def _recalc_acuracia(self):
        for ft, h in self.feature_hits.items():
            total = h['acertos'] + h['erros']
            self.acuracia[ft] = h['acertos'] / total if total > 0 else 0

    def carregar(self, base_dir):
        p = Path(base_dir) / 'learning_state.json'
        if not p.exists():
            return
        try:
            st = json.loads(p.read_text(encoding='utf-8'))
            for k, v in st.get('pesos', {}).items():
                if k in self.pesos and isinstance(v, (int, float)):
                    self.pesos[k] = max(-1.0, min(1.0, float(v)))
            for k, v in st.get('feature_hits', {}).items():
                self.feature_hits[k] = {'acertos': int(v.get('acertos', 0)), 'erros': int(v.get('erros', 0))}
            morto = st.get('morto', [])
            if isinstance(morto, list):
                self.morto = set(morto)
            from collections import deque
            self.resultados = deque(st.get('resultados', [])[-500:], maxlen=5000)
            self.previsoes = deque(st.get('previsoes', [])[-500:], maxlen=5000)
            self._recalc_acuracia()
            log.info(f"[LEARN] estado carregado: {len(self.resultados)} resultados, "
                     f"{len(self.morto)} features mortas")
        except Exception as e:
            log.warning(f"[LEARN] falha ao carregar: {e}")

    def carregar_aprendizado(self, base_dir):
        """Alias de compatibilidade para o nome antigo."""
        self.carregar(base_dir)

    def salvar(self, base_dir):
        try:
            out = Path(base_dir)
            out.mkdir(parents=True, exist_ok=True)
            st = {
                'pesos': dict(self.pesos),
                'feature_hits': {k: dict(v) for k, v in self.feature_hits.items()},
                'acuracia': dict(self.acuracia),
                'morto': sorted(self.morto),
                'resultados': list(self.resultados)[-500:],
                'previsoes': list(self.previsoes)[-500:],
                'salvo_em': datetime.now().isoformat(timespec='seconds')
            }
            (out / 'learning_state.json').write_text(
                json.dumps(st, ensure_ascii=False, indent=1), encoding='utf-8')
        except Exception as e:
            log.warning(f"[LEARN] falha ao salvar: {e}")

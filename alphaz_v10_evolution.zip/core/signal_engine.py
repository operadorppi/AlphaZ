# -*- coding: utf-8 -*-
"""
core/signal_engine.py — Engine de scoring e sinais.

Extrai de Analise:
  - PESOS_INICIAIS (linha 1294)
  - _avaliar (linha 2096 — ~500 linhas de scoring heurístico)
  - _suavizar_sinal (delegado para PositionManager)
  - _calcular (linha 1871 — prepara features por segundo)
  - get_features, get_sinais

O SignalEngine NÃO conhece posição nem risco.
Ele recebe features e produz (lado, score, confianca, motivos, contrib).
"""

import math
import time
import logging
from collections import defaultdict, OrderedDict
from datetime import date

from features import (
    fase_sessao, dias_ate_vencimento, classificar_corretora,
    EWMAZScore,
)
from core.learning import PESOS_INICIAIS, Learning
from core.regime_detector import RegimeDetector

log = logging.getLogger(__name__)


class SignalEngine:
    """Recebe features, produz sinais. Não conhece posição nem risco."""

    def __init__(self, market_state, learning=None, regime=None,
                 config=None, ativo_principal='WINV26', ativo_contexto='WDOU26'):
        self.state = market_state
        self.learning = learning or Learning(config)
        self.regime = regime or RegimeDetector(config)
        self.config = config or {}
        self.ativo_principal = ativo_principal
        self.ativo_contexto = ativo_contexto

        self.features = {}
        self.sinais = {}
        self.confianca_ewma = 0.0
        self._score_confirmado = 0.0
        self._sinal_streak = 0
        self._sinal_anterior_bruto = 0
        self._normalizar_score = bool(self.config.get('normalizar_score', False))
        self._zscore_trackers = {}

    def calcular(self, seg, skip_avaliar=False):
        """Calcula features do segundo para todos os ativos no buffer."""
        for ativo, negs in list(self.state.buffer.items()):
            if not negs:
                continue
            
            # v10.2: Deduplicação antes do cálculo (Seção 18)
            # Filtra negócios repetidos no mesmo ms com mesma assinatura
            vistos = set()
            negs_unicos = []
            for n in negs:
                # Assinatura: (preco, qtd, agressor, comp, vend)
                sig = (n['preco'], n['qtd'], n['agressor'], n.get('compradora'), n.get('vendedora'))
                if sig not in vistos:
                    vistos.add(sig)
                    negs_unicos.append(n)
            
            negs = negs_unicos
            vc = sum(n['qtd'] for n in negs if n['agressor'] == 'Comprador')
            vv = sum(n['qtd'] for n in negs if n['agressor'] == 'Vendedor')
            vt = vc + vv
            n = len(negs)
            aggr = (vc - vv) / vt if vt > 0 else 0.0
            precos = [x['preco'] for x in negs if x['preco'] > 0]
            dp = (precos[-1] - precos[0]) if len(precos) >= 2 else 0.0
            eff = abs(dp) / vt if vt > 0 else 0.0
            fp = (sum(1 for i in range(1, n) if negs[i]['agressor'] == negs[i - 1]['agressor'])
                  / max(n - 1, 1))
            vc2 = defaultdict(int)
            for nc in negs:
                for lado in ('compradora', 'vendedora'):
                    c = nc[lado]
                    if c and c not in ('None', ''):
                        vc2[c] += nc['qtd']
            tc = sum(vc2.values())
            shares = [v / tc for v in vc2.values()] if tc > 0 else []
            hhi = sum(s * s for s in shares) if shares else 0.0

            f = {
                'time_ms': seg * 1000, 'ativo': ativo, 'n': n, 'vol_total': vt,
                'vol_compr': vc, 'vol_vend': vv, 'aggr_imb': aggr,
                'preco_ini': precos[0] if precos else 0, 'preco_fim': precos[-1] if precos else 0,
                'delta_preco': dp, 'price_eff': eff, 'fluxo_persist': fp, 'hhi': hhi,
                'top_corretoras': sorted(vc2.items(), key=lambda x: -x[1])[:6],
                'avg_trade_size': round(vt / n, 1) if n > 0 else 0,
                'max_trade_size': max((x['qtd'] for x in negs), default=0),
                'trades_per_sec': n,
            }

            # Aceleração
            # Evitar list() para não copiar o objeto inteiro na memória
            hist_ant = self.state.historico.get(ativo, [])
            if len(hist_ant) >= 3:
                rec = [h['aggr_imb'] for h in hist_ant[-3:]]
                ant3 = [h['aggr_imb'] for h in hist_ant[-6:-3]] if len(hist_ant) >= 6 else [h['aggr_imb'] for h in hist_ant[:min(3, len(hist_ant))]]
                f['aceleracao'] = (sum(rec) / len(rec)) - (sum(ant3) / len(ant3))
            else:
                f['aceleracao'] = 0.0

            # CVD
            st2 = self.state.stats.get(ativo)
            cvd = (st2['vc'] - st2['vv']) if st2 else 0
            f['cvd_total'] = cvd
            f['cvd_div'] = 0  # simplificado no signal_engine

            # Volatilidade
            prev_p = self.state._ultimo_preco_fim.get(ativo, 0.0)
            preco_f = f['preco_fim']
            if prev_p > 0 and preco_f > 0:
                ret = preco_f / prev_p - 1.0
                self.state._ewma_ret2[ativo] = 0.9 * self.state._ewma_ret2.get(ativo, 0.0) + 0.1 * ret * ret
            self.state._ultimo_preco_fim[ativo] = preco_f
            f['realized_vol_bps'] = round(math.sqrt(self.state._ewma_ret2.get(ativo, 0.0)) * 10000, 2)
            hp = [h['preco_fim'] for h in hist_ant[-60:] if h.get('preco_fim', 0) > 0]
            if len(hp) >= 2:
                mid_p = (max(hp) + min(hp)) / 2
                f['range_vol_bps'] = round((max(hp) - min(hp)) / mid_p * 10000, 2) if mid_p > 0 else 0.0
            else:
                f['range_vol_bps'] = 0.0
            f['fase_sessao'] = fase_sessao(seg * 1000)
            f['dias_ate_venc'] = dias_ate_vencimento(ativo) or 0

            # Absorção
            if vt > 10 and abs(dp) > 0:
                f['absorcao_ratio'] = vt / abs(dp)
            elif vt > 10:
                f['absorcao_ratio'] = vt * 10
            else:
                f['absorcao_ratio'] = 0

            # OFI
            ofi_tracker = self.state.trackers[ativo]['ofi']
            ofi_d = ofi_tracker.get_ofi()
            f['ofi_total'] = ofi_d['ofi_total']
            f['ofi_ewma'] = ofi_d['ofi_ewma']

            self.features[ativo] = f
            with self.state.lock:
                self.state.features_por_seg[(ativo, seg)] = f
                max_feat = self.config.get('features_seg_max', 7200)
                while len(self.state.features_por_seg) > max_feat:
                    self.state.features_por_seg.popitem(last=False)
            self.state.historico[ativo].append(f)

            if not skip_avaliar:
                self.avaliar(ativo, f)

            # Alimenta trackers
            tr = self.state.trackers[ativo]
            ts_now = time.time()
            tr['aggr'].add(abs(f['aggr_imb']), ts_now)
            tr['eff'].add(f['price_eff'], ts_now)
            tr['acel'].add(abs(f['aceleracao']), ts_now)
            bs = self.state.book_stats.get(ativo)
            if bs:
                tr['book_imb'].add(abs(bs['imb']), ts_now)
            if f['preco_fim'] > 0:
                tr['range'].atualizar(f['preco_fim'], ts_now)

    def avaliar(self, ativo, f):
        """Avalia features e produz score + sinal.

        Esta é a função central de scoring heurístico.
        O ML scorer (se carregado) é combinado aqui.
        """
        aggr = f['aggr_imb']
        eff = f['price_eff']
        dp = f['delta_preco']
        vol = f['vol_total']
        preco = f['preco_fim']
        acel = f.get('aceleracao', 0.0)
        hist = self.state.historico.get(ativo, [])

        tr = self.state.trackers[ativo]
        p_aggr = self.config.get('percentil_aggr', 0.85)
        fb_aggr = self.config.get('fallback_aggr_min', 0.3)
        limiar_aggr = tr['aggr'].percentil(p_aggr, fb_aggr)
        limiar_eff = tr['eff'].percentil(self.config.get('percentil_eficiencia', 0.85),
                                         self.config.get('fallback_eficiencia_min', 0.001))
        limiar_acel = tr['acel'].percentil(self.config.get('percentil_aceleracao', 0.85),
                                          self.config.get('fallback_aceleracao_min', 0.05))

        score = 0.0
        motivos = []
        contrib = []

        regime_info = self.regime.detectar(ativo, hist)
        f['regime'] = regime_info.get('regime', 'lateral')

        def add(key, mult, texto):
            nonlocal score
            regime = f.get('regime', 'lateral')
            peso_base = self.learning.pesos_regime.get(regime, self.learning.pesos).get(key, self.learning.pesos.get(key, 0.0))
            if self._normalizar_score:
                zt = self._zscore_trackers.get(key)
                if zt is None:
                    zt = EWMAZScore()
                    self._zscore_trackers[key] = zt
                mult = zt.z(mult)
                zt.atualizar(mult)
            score += peso_base * mult
            contrib.append((key, mult))
            motivos.append(texto)

        # Divergência CVD
        cvd_d = f.get('cvd_div', 0)
        if cvd_d == -1:
            add('cvd_div', -0.6, 'divergencia bearish')
        elif cvd_d == 1:
            add('cvd_div', 0.6, 'divergencia bullish')

        lado = 1 if aggr > 0 else -1

        # Preço andando
        if abs(aggr) >= limiar_aggr:
            preco_andando = (dp > 0 and lado > 0) or (dp < 0 and lado < 0)
            if preco_andando and abs(dp) > 5:
                add('preco_andando', 0.3, f"preco +{dp:.0f}")
            elif preco_andando:
                add('preco_andando', 0.15, f"preco ({dp:.0f})")
            elif not preco_andando and abs(dp) > 2:
                add('preco_andando', -0.3, f"preco CONTRA ({dp:.0f})")

        # Eficiência
        if vol > 10:
            if eff > limiar_eff:
                add('eficiencia', 1.0, f"eff {eff:.4f}")
            elif eff < self.config.get('fallback_absorcao_eficiencia_max', 0.001) and abs(aggr) > 0.3:
                add('eficiencia', -0.8, f"absorcao eff={eff:.4f}")

        # Aceleração
        if abs(acel) > limiar_acel and (acel > 0) == (aggr > 0):
            add('aceleracao', 1.0, f"acelera {acel:+.2f}")
        elif abs(acel) > limiar_acel and (acel > 0) != (aggr > 0):
            add('aceleracao', -0.75, f"desacelera {acel:+.2f}")

        # Persistência
        seguidos = 0
        for h in reversed(hist[-5:]):
            if (h['aggr_imb'] > 0) == (aggr > 0):
                seguidos += 1
            else:
                break
        if seguidos >= 4:
            add('persistencia', 1.0, f"{seguidos}s seguidos")
        elif seguidos >= 3:
            add('persistencia', 0.667, f"{seguidos}s seguidos")

        # Regime ajuste
        result = self.regime.ajustar(ativo, score, motivos, regime_info, hist)
        score, regime = result[0], result[1]
        estrategia = result[2] if len(result) > 2 else {}

        # ML Score
        ml_prob = 0.5
        if hasattr(self, 'scorer') and self.scorer and ativo in getattr(self.scorer, 'prob', {}):
            ml_prob = self.scorer.prob[ativo]
            ml_threshold = self.config.get('ml_threshold', 0.6)
            ml_score = (ml_prob - 0.5) * 2
            score = 0.6 * score + 0.4 * ml_score * 3.0
            motivos.append(f'ML={ml_prob:.2f}')

        # Sinal
        sinal = 0
        if score > 0.5:
            sinal = lado
        else:
            if sinal == 0:
                motivos = ['fluxo fraco']

        # Persistência do sinal
        if sinal != 0 and sinal == self._sinal_anterior_bruto:
            self._sinal_streak += 1
        elif sinal != 0:
            self._sinal_streak = 1
        else:
            self._sinal_streak = 0
        self._sinal_anterior_bruto = sinal

        # Confiança EWMA
        alpha = 0.3
        if abs(score) < 0.1:
            self.confianca_ewma *= 0.85
        else:
            self.confianca_ewma = (1 - alpha) * self.confianca_ewma + alpha * abs(score)

        conf = min(abs(score) / 3.0, 1.0)

        # TP/SL
        ranges_hist = []
        for i in range(60, min(len(hist), 600), 60):
            ph_i = [h['preco_fim'] for h in hist[-i:] if h['preco_fim'] > 0]
            if len(ph_i) >= 2:
                ranges_hist.append(max(ph_i) - min(ph_i))
        vol_p = sum(ranges_hist) / len(ranges_hist) if ranges_hist else abs(dp)
        if vol_p < 100:
            vol_p = 100

        estrategias = self.config.get('estrategias', {})
        estrategia = estrategias.get(regime, estrategias.get('lateral', {}))
        tp_mult = estrategia.get('tp_mult', 1.0)
        sl_mult = estrategia.get('sl_mult', 1.0)
        tp = round(vol_p * 0.6 * tp_mult / 5) * 5
        sl = round(vol_p * 0.4 * sl_mult / 5) * 5
        min_sl = int(150 * sl_mult)
        min_tp = int(200 * tp_mult)
        if sl < min_sl:
            sl = min_sl
        if tp < min_tp:
            tp = min_tp

        # Sizing por confiança — EXATAMENTE como RiskManager.calcular_tp_sl
        # (evita divergência entre o TP/SL exibido no sinal e o usado na execução).
        if conf >= 0.8:
            conf_tp_mult, conf_sl_mult = 1.2, 0.85
        elif conf >= 0.5:
            conf_tp_mult, conf_sl_mult = 1.0, 1.0
        else:
            conf_tp_mult, conf_sl_mult = 0.8, 1.15

        tp = round(tp * conf_tp_mult / 5) * 5
        sl = round(sl * conf_sl_mult / 5) * 5
        if sl < min_sl:
            sl = min_sl
        if tp < min_tp:
            tp = min_tp

        from core.risk_manager import custo_execucao
        custo = custo_execucao(ativo, self.config)
        tp -= custo
        sl += custo

        # Sinais
        self.sinais[ativo] = {
            'sinal': sinal, 'confianca': round(conf, 3), 'score': round(score, 3),
            'motivos': motivos or ['neutro'], 'lado_fluxo': 'C' if aggr > 0 else 'V',
            'tp': tp, 'sl': sl,
            'ml_prob': round(ml_prob, 3),
        }

        return self.sinais[ativo]

    def get_features(self):
        """Retorna features com regime e OHLC."""
        import copy
        feat = copy.deepcopy(self.features)
        for ativo, f in feat.items():
            if ativo.startswith('_'):
                continue
            hist = list(self.state.historico.get(ativo, []))
            if hist:
                ri = self.regime.detectar(ativo, hist)
                f['regime'] = ri.get('regime', 'lateral')
                f['regime_info'] = ri
            if ativo in self.state.ohlc:
                oh = self.state.ohlc[ativo]
                f['abertura_dia'] = oh['abertura']
                f['maxima_dia'] = oh['maxima']
                f['minima_dia'] = oh['minima']
                f['fechamento_dia'] = oh['fechamento']
        return feat

    def get_sinais(self):
        return dict(self.sinais)

# -*- coding: utf-8 -*-
"""
core/app.py — Orquestrador principal com loop RTD completo.

v10.0 — Migração completa do loop RTD de motor_rt_alphaz.py.

Estrutura:
  App
  ├── MarketState        (estado de mercado)
  ├── SignalEngine       (features + scoring)
  ├── PositionManager    (abrir/fechar posições)
  ├── RiskManager        (circuit breaker, TP/SL, horário)
  ├── RegimeDetector     (regime de mercado)
  ├── Learning           (pesos, MFE/MAE)
  ├── Persistence        (trades, decisões, checkpoints)
  ├── Metrics            (acuracia, PF, Sharpe)
  ├── EventClock          (relógio mestre)
  ├── FileStorage        (captura bruta JSONL)
  ├── ScorerML           (ML, opcional)
  └── Loop RTD            (PumpEvents, RefreshData, reconexão)
"""

import os
import sys
import time
import math
import queue
import signal
import logging
import threading
from collections import defaultdict
from datetime import datetime, date
from http.server import ThreadingHTTPServer

log = logging.getLogger(__name__)

# v10.2: Helper centralizado para resolver o shadow import de config.py na raiz
def _load_root_config():
    import importlib.util
    from pathlib import Path
    root_path = Path(__file__).resolve().parent.parent
    config_py = root_path / "config.py"
    if config_py.exists():
        spec = importlib.util.spec_from_file_location("root_config", str(config_py))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    return None

_root_cfg_mod = _load_root_config()
CONFIG = _root_cfg_mod.get_config_dict() if _root_cfg_mod else {}
SAVE_DIR = CONFIG.get('save_dir', 'D:\\MarketData\\mimo')
ATIVO_PRINCIPAL = CONFIG.get('ativo_principal', 'WINV26')
ATIVO_CONTEXTO = CONFIG.get('ativo_contexto', 'WDOU26')

from adapters.com_watchdog import COMHeartbeatMonitor
from adapters.file_storage import flush_buffers_with_retry

from core.market_state import MarketState, EstadoAtivo, extrair_book_snapshot, comparar_books
from core.persistence import Persistence
from core.metrics import Metrics
from core.event_clock import EventClock, parse_hms_ms
from core.regime_detector import RegimeDetector
from core.learning import Learning
from core.risk_manager import RiskManager
from core.position_manager import PositionManager
from core.signal_engine import SignalEngine

from adapters.file_storage import FileStorage

# motor_web (conexão COM)
import importlib.util as _ilu
import os as _os
_root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
_mw_spec = _ilu.spec_from_file_location('motor_web_root', _os.path.join(_root, 'motor_web.py'))
_mw = _ilu.module_from_spec(_mw_spec)
_mw_spec.loader.exec_module(_mw)

ERROS_GLOBAIS = defaultdict(int)


def _tod_ms(dt=None):
    dt = dt or datetime.now()
    return ((dt.hour * 3600 + dt.minute * 60 + dt.second) * 1000) + dt.microsecond // 1000


def fnum(v, d=0.0):
    try:
        return float(v) if v is not None else d
    except (TypeError, ValueError):
        return d


def fint(v, d=0):
    try:
        return int(float(v)) if v is not None else d
    except (TypeError, ValueError):
        return d


def sstr(v):
    return "" if v is None else str(v).strip()


def extrair_niveis_book(estado, n_niveis):
    bid_levels = []
    ask_levels = []
    for lvl in range(n_niveis):
        bid = estado.book_bid[lvl]
        ask = estado.book_ask[lvl]
        bid_levels.append((fnum(bid.get('OCP', 0)), fint(bid.get('VOC', 0))))
        ask_levels.append((fnum(ask.get('OVD', 0)), fint(ask.get('VOV', 0))))
    return bid_levels, ask_levels


def snapshot_book(estado):
    from collections import defaultdict as _dd
    snap = _dd(lambda: {'bid_vol': 0, 'ask_vol': 0, 'bid_preco': 0,
                        'ask_preco': 9e18, 'bid_niveis': 0, 'ask_niveis': 0,
                        'bid_vol_top3': 0, 'ask_vol_top3': 0})
    total_bid_vol = 0
    total_ask_vol = 0
    book_split = CONFIG.get('book_split', 30)
    for lvl in range(book_split):
        d = estado.book_bid[lvl]
        vol = fint(d.get('VOC', 0))
        if vol <= 0:
            continue
        preco = fnum(d.get('OCP', 0))
        broker = str(d.get('ACP', '')).strip() or '_anon'
        if broker == 'None':
            broker = '_anon'
        snap[broker]['bid_vol'] += vol
        snap[broker]['bid_niveis'] += 1
        if preco > snap[broker]['bid_preco']:
            snap[broker]['bid_preco'] = preco
        total_bid_vol += vol
    for lvl in range(book_split):
        d = estado.book_ask[lvl]
        vol = fint(d.get('VOV', 0))
        if vol <= 0:
            continue
        preco = fnum(d.get('OVD', 0))
        broker = str(d.get('AVD', '')).strip() or '_anon'
        if broker == 'None':
            broker = '_anon'
        snap[broker]['ask_vol'] += vol
        snap[broker]['ask_niveis'] += 1
        if 0 < preco < snap[broker]['ask_preco']:
            snap[broker]['ask_preco'] = preco
        total_ask_vol += vol
    return dict(snap), total_bid_vol, total_ask_vol


class App:
    """Orquestrador principal com loop RTD completo."""

    def __init__(self, config=None):
        self.config = config or CONFIG
        self.save_dir = self.config.get('save_dir', SAVE_DIR)
        self.ativo_principal = self.config.get('ativo_principal', ATIVO_PRINCIPAL)
        self.ativo_contexto = self.config.get('ativo_contexto', ATIVO_CONTEXTO)
        self.session_ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.tempo_inicio = time.time()
        self._shutdown = threading.Event()

        # ---- Composição de módulos core/ ----
        self.clock = EventClock()
        self.market_state = MarketState(base_dir=self.save_dir)
        self.persistence = Persistence(self.save_dir, self.session_ts)
        self.learning = Learning(config=self.config)
        self.regime = RegimeDetector(config=self.config)
        self.risk = RiskManager(config=self.config)
        self.position = PositionManager(
            self.risk, self.persistence, self.learning,
            config=self.config, ativo_principal=self.ativo_principal
        )
        self.signal = SignalEngine(
            self.market_state, self.learning, self.regime,
            config=self.config, ativo_principal=self.ativo_principal,
            ativo_contexto=self.ativo_contexto
        )
        self.metrics = Metrics(
            resultados=self.learning.resultados,
            previsoes=self.learning.previsoes,
            pesos=self.learning.pesos,
            feature_hits=self.learning.feature_hits,
            acuracia=self.learning.acuracia,
        )
        self.captura = FileStorage(self.save_dir, self.session_ts)

        # Restaurar checkpoint de posição
        pos = self.persistence.carregar_checkpoint()
        if pos:
            self.position.posicao = pos

        # Carregar aprendizado
        self.learning.carregar(self.save_dir)

        # ML Scorer (opcional)
        self.scorer = None
        self._carregar_scorer()

        # RTD
        self.estados = {}
        self._srv = None
        self._book_map = {}
        self._tt_map = {}
        self._topic_map = {}
        self._conexao_ok = False
        self._ultima_reconexao = 0.0
        self.fila_eventos = queue.SimpleQueue()

        log.info(f"[APP] Inicializado: {self.ativo_principal} × {self.ativo_contexto}")

    def _carregar_scorer(self):
        modelo_path = self.config.get('ml_modelo', '')
        if not modelo_path or not os.path.exists(modelo_path):
            log.info('[ML] Sem modelo treinado — usando apenas heuristica')
            return
        try:
            _spec2 = importlib.util.spec_from_file_location(
                'scorer_root', os.path.join(_root, 'scorer.py'))
            _scorer_mod = importlib.util.module_from_spec(_spec2)
            _spec2.loader.exec_module(_scorer_mod)
            ScorerML = _scorer_mod.ScorerML
            ativos = [self.ativo_principal]
            if self.ativo_contexto:
                ativos.append(self.ativo_contexto)
            self.scorer = ScorerML(modelo_path, ativos)
            self.signal.scorer = self.scorer
            log.info(f'[ML] Scorer carregado: {modelo_path}')
        except Exception as e:
            log.warning(f'[ML] Falha ao carregar modelo: {e}')

    # ---- Conexão RTD ----

    def _conectar_e_descobrir(self):
        import comtypes.client
        srv, IRTDUpdateEvent = _mw.conectar_servidor()
        notify = threading.Event()
        disc = threading.Event()
        cb = _mw._criar_callback(IRTDUpdateEvent, notify, disc)
        srv.ServerStart(cb)
        deadline = time.perf_counter() + 5.0
        while time.perf_counter() < deadline:
            comtypes.client.PumpEvents(0.1)
        book_map, tt_map = {}, {}
        for i in range(_mw.MAX_JANELAS_RTD):
            for kind, prefix in (("book", "BOOK"), ("tt", "T&T")):
                try:
                    tid, val = _mw._connect(srv, [f"{prefix}{i}", "INFO", "ATV"])
                    v = _mw._normalizar_simbolo(val)
                    if v and not _mw._topico_invalido(v) and v in self.config["ativos"]:
                        if kind == "book":
                            book_map[i] = v
                        else:
                            tt_map[i] = v
                except Exception:
                    ERROS_GLOBAIS['descoberta_topico'] += 1
            comtypes.client.PumpEvents(0.01)
        log.info(f"[DESCOBERTA] Book: {book_map}")
        log.info(f"[DESCOBERTA] T&T:  {tt_map}")
        return srv, book_map, tt_map

    def _assinar_topicos(self, srv, book_map, tt_map):
        import comtypes.client
        topic_map = {}
        n = 0
        BK_BID = ('OCP', 'VOC', 'ACP')
        BK_ASK = ('OVD', 'VOV', 'AVD')
        TT = ('DAT', 'PRE', 'QUL', 'AGR', 'ACP', 'AVD')
        BOOK_SPLIT = self.config.get('book_split', 30)
        BOOK_LINHAS = self.config.get('book_linhas', 60)
        TT_LINHAS = self.config.get('tt_linhas', 1000)

        for j_idx, sym in book_map.items():
            for linha in range(BOOK_LINHAS):
                campos = BK_BID if linha < BOOK_SPLIT else BK_ASK
                for field in campos:
                    try:
                        tid, _ = _mw._connect(srv, [f"BOOK{j_idx}", field, str(linha)])
                        topic_map[tid] = ("book", j_idx, sym, field, linha)
                        n += 1
                    except Exception:
                        ERROS_GLOBAIS['assinar_book'] += 1
            comtypes.client.PumpEvents(0.05)

        for j_idx, sym in tt_map.items():
            for linha in range(TT_LINHAS):
                for field in TT:
                    try:
                        tid, _ = _mw._connect(srv, [f"T&T{j_idx}", field, str(linha)])
                        topic_map[tid] = ("tt", j_idx, sym, field, linha)
                        n += 1
                    except Exception:
                        ERROS_GLOBAIS['assinar_tt'] += 1
            comtypes.client.PumpEvents(0.05)

        for j_idx, sym in tt_map.items():
            try:
                tid, _ = _mw._connect(srv, [f"T&T{j_idx}", "INFO", "NEG"])
                topic_map[tid] = ("neg", j_idx, sym, "NEG", 0)
                n += 1
            except Exception:
                ERROS_GLOBAIS['assinar_neg'] += 1

        log.info(f"[ASSINATURA] Total: {n} tópicos")
        return topic_map

    def _processar_dados(self, topic_map, data, estados):
        """Captura T&T com dedup por frequência."""
        novos = []
        for tid, val in _mw.parse_refresh_data(data):
            info = topic_map.get(tid)
            if not info:
                continue
            kind, j_idx, sym, field, linha = info
            estado = estados.get(sym)
            if not estado:
                continue
            if kind == "book":
                if linha < self.config.get('book_split', 30):
                    estado.book_bid[linha][field] = val
                else:
                    estado.book_ask[linha - self.config.get('book_split', 30)][field] = val
            elif kind == "tt":
                estado.tt_rows[linha][field] = val
            elif kind == "neg":
                estado.neg_total = fint(val)

        for sym, estado in estados.items():
            if estado.warmup_tt < 60:
                estado.warmup_tt += 1
                if estado.warmup_tt == 60:
                    estado.vistos_tt.clear()
                    estado.baseline_tt = False
                    estado.baseline_pending_tt = True
                continue

            estado.ciclo_contador_tt += 1
            current_counts = {}
            example_r = {}
            for r in estado.tt_rows:
                pre = fnum(r.get("PRE"))
                if pre <= 0:
                    continue
                sig = (sstr(r.get("DAT")), sstr(r.get("ACP")), pre,
                       fint(r.get("QUL")), sstr(r.get("AVD")), sstr(r.get("AGR")))
                current_counts[sig] = current_counts.get(sig, 0) + 1
                example_r[sig] = r

            if estado.baseline_pending_tt:
                estado.vistos_tt = dict(current_counts)
                estado.baseline_pending_tt = False
                estado.baseline_tt = bool(current_counts)
                continue

            for sig, count in current_counts.items():
                seen = estado.vistos_tt.get(sig, 0)
                if count > seen:
                    diff = count - seen
                    estado.vistos_tt[sig] = count
                    r = example_r[sig]
                    tms = parse_hms_ms(r.get("DAT"))
                    if tms <= 0:
                        continue
                    preco = fnum(r.get("PRE"))
                    qtd = fint(r.get("QUL"))
                    if preco <= 0 or qtd <= 0:
                        continue
                    faixa = self.config.get('faixas_preco', {}).get(sym[:3], [0, 999999999])
                    if preco < faixa[0] or preco > faixa[1]:
                        continue
                    ultimo_preco = estado._ultimo_preco_valido or preco
                    if ultimo_preco > 0 and preco > 0:
                        salto = abs(preco - ultimo_preco) / ultimo_preco
                        if salto > self.config.get('max_salto_preco_pct', 0.15):
                            continue
                    estado._ultimo_preco_valido = preco
                    agr_raw = sstr(r.get("AGR")).lower()
                    comp = sstr(r.get("ACP"))
                    vend = sstr(r.get("AVD"))
                    agr = "Comprador" if "compr" in agr_raw else ("Vendedor" if "vend" in agr_raw else "neutro")
                    for _ in range(diff):
                        novos.append((sym, tms, preco, qtd, agr, comp, vend))
                        estado.neg_detectados += 1
                        estado.ultimo_neg_tempo = time.time()

            if len(estado.vistos_tt) > 40_000 and estado.ciclo_contador_tt % 5 == 0:
                n_remove = len(estado.vistos_tt) // 20
                for sig in sorted(estado.vistos_tt, key=estado.vistos_tt.get)[:n_remove]:
                    del estado.vistos_tt[sig]

        return novos

    def _sync_estados(self):
        for sym in set(self._book_map.values()) | set(self._tt_map.values()):
            if sym not in self.estados:
                self.estados[sym] = EstadoAtivo(sym)

    def _reconectar(self):
        agora = time.time()
        if agora - getattr(self, '_ultima_reconexao', 0) < 10:
            return False
        self._ultima_reconexao = agora
        if not hasattr(self, '_reconexoes_recentes'):
            self._reconexoes_recentes = []
        self._reconexoes_recentes = [t for t in self._reconexoes_recentes if agora - t < 180]
        self._reconexoes_recentes.append(agora)
        _ja_dados = any(e.neg_detectados > 0 for e in self.estados.values())
        if len(self._reconexoes_recentes) > 5 and _ja_dados:
            log.error('[COM] %d reconexoes em <180s apos dados — encerrando',
                      len(self._reconexoes_recentes))
            sys.exit(1)
        elif len(self._reconexoes_recentes) > 5 and not _ja_dados:
            log.info('[COM] %d reconexoes mas sem dados — RTD pode nao estar pronto' %
                      len(self._reconexoes_recentes))
        log.warning("Tentando reconectar ao RTD...")
        try:
            if self._srv:
                try:
                    self._srv.ServerTerminate()
                except Exception:
                    pass
                self._srv = None
            self._srv, self._book_map, self._tt_map = self._conectar_e_descobrir()
            if not self._book_map and not self._tt_map:
                log.error("Sem janelas RTD. ProfitChart aberto?")
                self._conexao_ok = False
                return False
            self._sync_estados()
            self._topic_map = self._assinar_topicos(self._srv, self._book_map, self._tt_map)
            self._conexao_ok = True
            self._loop_beat = time.time()
            self._com_stuck = False
            log.info("Reconexão bem-sucedida")
            return True
        except Exception as e:
            log.error("Falha na reconexão: %s", e)
            self._conexao_ok = False
            return False

    # ---- Loop principal ----

    def run(self):
        logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")

        def persistence_worker():
            while not self._shutdown.is_set():
                self.persistence.flush()
                time.sleep(0.5)
        threading.Thread(target=persistence_worker, daemon=True).start()

        try:
            self._srv, self._book_map, self._tt_map = self._conectar_e_descobrir()
            if not self._book_map and not self._tt_map:
                log.error("Sem janelas RTD. ProfitChart aberto?")
                return
            self._sync_estados()
            self._topic_map = self._assinar_topicos(self._srv, self._book_map, self._tt_map)
            self._conexao_ok = True
        except Exception as e:
            log.error("Falha na conexão inicial: %s", e)
            self._conexao_ok = False

        # Dashboard HTTP
        from adapters.dashboard_api import DashboardAPI
        DashboardAPI.app = self
        server = ThreadingHTTPServer(
            (self.config.get('web_host', '127.0.0.1'),
             self.config.get('web_port', 5001)),
            DashboardAPI)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        log.info(f"[OK] Dashboard: http://{self.config.get('web_host','127.0.0.1')}:{self.config.get('web_port',5001)}/")

        self._loop()

    def _loop(self):
        import comtypes.client
        ultimo_save = time.time()
        falhas = 0
        ultimo_preco_check = 0
        ultimo_backlog_log = 0
        ultimo_captura_log = 0
        ultimo_scorer_log = 0
        self._loop_beat = time.time()
        self._com_stuck = False
        _com_timeout = 15.0
        
        # B2: Integrado com o monitor robusto de adapters/
        mon = COMHeartbeatMonitor(self._srv, timeout_s=_com_timeout)
        mon.start()

        while not self._shutdown.is_set():
            try:
                comtypes.client.PumpEvents(0.005)
                self._loop_beat = time.time()
                time.sleep(0.001)

                if self._conexao_ok and self._srv:
                    try:
                        data = _mw._refresh(self._srv)
                        falhas = 0
                        mon.heartbeat()
                        novos = self._processar_dados(self._topic_map, data, self.estados)
                        if novos and not self._shutdown.is_set():
                            self.fila_eventos.put(novos, timeout=1.0)
                            self.captura.registrar_negocios(novos)
                    except Exception:
                        falhas += 1
                        ERROS_GLOBAIS['refresh_rtd'] += 1
                        if falhas >= self.config.get('max_refresh_falhas', 200):
                            log.warning("Muitas falhas, reconectando...")
                            self._reconectar()
                            falhas = 0
                    if novos or self.fila_eventos.qsize() > 0:
                        time.sleep(0.002)
                    else:
                        time.sleep(0.05)

                if mon.stuck_event.is_set():
                    self._com_stuck = True
                    log.error('[COM-WATCHDOG] Hang detectado — reconectando')
                    self._com_stuck = False
                    mon.stuck_event.clear()
                    self._reconectar()
                    self._loop_beat = time.time()
                    falhas = 0
                if not self._conexao_ok:
                    if time.time() - self._ultima_reconexao > 5:
                        self._ultima_reconexao = time.time()
                        self._reconectar()
                    time.sleep(0.1)

                # Worker processa fila
                try:
                    while True:
                        novos = self.fila_eventos.get_nowait()
                        # Alimentar market_state
                        for neg in novos:
                            sym, tms, preco, qtd, agr, comp, vend = neg
                            self.market_state.alimentar_negocio(sym, tms, preco, qtd, agr, comp, vend)
                        # Calcular features do último segundo
                        if novos:
                            seg = max(tms for _, tms, *_ in novos) // 1000
                            self.signal.calcular(seg, skip_avaliar=False)
                        # Alimentar ML scorer
                        if self.scorer:
                            agora_epoch_ms = int(time.time() * 1000)
                            agora_tod_ms = _tod_ms()
                            offset_epoch = agora_epoch_ms - agora_tod_ms
                            for neg in novos:
                                tms_epoch = offset_epoch + neg[1]
                                self.scorer.evento(neg[0], tms_epoch, neg[2], neg[3], neg[4], neg[5], neg[6])
                except queue.Empty:
                    pass

                # Observabilidade do scorer
                if self.scorer and getattr(self.scorer, 'fallos', 0):
                    if time.time() - ultimo_scorer_log > 300:
                        ultimo_scorer_log = time.time()
                        est = self.scorer.estado_salud()
                        log.error('[ML] scorer %d falhas (erro: %s)', est['fallos'], est.get('ultimo_error'))

                # Backlog
                qsz = self.fila_eventos.qsize()
                if qsz > 2000 and time.time() - ultimo_backlog_log > 30:
                    ultimo_backlog_log = time.time()
                    log.warning(f"[PIPE] backlog: {qsz} lotes")

                # Saúde da captura
                if time.time() - ultimo_captura_log > 600:
                    ultimo_captura_log = time.time()
                    if self.captura:
                        rej = self.captura.stats()
                        if any(rej.values()):
                            log.warning(f"[CAPTURA] rejeitados: {rej}")
                        else:
                            log.info("[CAPTURA] saudável (0 rejeitados)")

                # Snapshot do book
                agora = time.time()
                book_split = self.config.get('book_split', 30)
                for sym, estado in self.estados.items():
                    book_mudou = any(estado.book_bid[i] for i in range(book_split)) or \
                                 any(estado.book_ask[i] for i in range(book_split))
                    tempo_sem_snap = agora - estado.book_ultimo_t
                    is_keepalive = (not book_mudou) and tempo_sem_snap >= 30.0
                    if not book_mudou and not is_keepalive:
                        continue
                    if book_mudou and tempo_sem_snap < 0.25:
                        continue

                    snap, bv, av = snapshot_book(estado)
                    ofi_tracker = self.market_state.trackers[sym]['ofi']
                    bid_levels_ofi, ask_levels_ofi = extrair_niveis_book(estado, ofi_tracker.niveis)
                    ofi_tracker.atualizar(bid_levels_ofi, ask_levels_ofi)
                    all_bid_levels, all_ask_levels = extrair_niveis_book(estado, book_split)
                    chave = (bv, av, tuple((b, s.get('bid_vol', 0), s.get('ask_vol', 0)) for b, s in snap.items()))
                    if chave != estado.book_ultimo_snap or is_keepalive:
                        estado.book_ultimo_snap = chave
                        estado.book_ultimo_t = agora
                        estado.ultimo_book_tempo = agora
                        self.market_state.alimentar_book(sym, snap, bv, av, ofi_tracker.get_ofi(), estado=estado)
                        if self.scorer:
                            book_snap = extrair_book_snapshot(estado)
                            self.scorer.book(sym, int(agora * 1000), book_snap)
                    if self.captura:
                        levels = {
                            'bid_preco': [b[0] for b in all_bid_levels] if all_bid_levels else [],
                            'bid_vol': [b[1] for b in all_bid_levels] if all_bid_levels else [],
                            'ask_preco': [a[0] for a in all_ask_levels] if all_ask_levels else [],
                            'ask_vol': [a[1] for a in all_ask_levels] if all_ask_levels else [],
                            'ofi': ofi_tracker.get_ofi(),
                        }
                        self.captura.registrar_book(sym, int(agora * 1000), snap, bv, av, levels=levels)

                # Verificar saídas em tempo real
                if agora - ultimo_preco_check >= 0.25:
                    ultimo_preco_check = agora
                    result = self.position.checar_saidas(
                        self.market_state.obter_ultimo_preco(self.ativo_principal, self.signal.features))
                    if result:
                        log.info("Posição fechada: %s", result)

                # Reconexão por falta de dados
                if self._conexao_ok and self._srv:
                    agora_check = time.time()
                    _ja_recebeu = any(e.neg_detectados > 0 for e in self.estados.values())
                    if _ja_recebeu:
                        sem_dados = any(
                            agora_check - e.ultimo_neg_tempo > 300
                            for e in self.estados.values()
                        )
                        if sem_dados and agora_check - ultimo_save > 30:
                            log.warning('[WATCHDOG] Parou ha 5min — reconectando...')
                            self._reconectar()
                    else:
                        if not getattr(self, '_logou_aguardando', False):
                            log.info('[WATCHDOG] Aguardando primeiro trade do RTD...')
                            self._logou_aguardando = True

                # Salvamento periódico
                if time.time() - ultimo_save >= self.config.get('save_intervalo', 60):
                    ultimo_save = time.time()
                    self.salvar_sessao()
                    if self.captura:
                        self.captura.flush()
            except Exception as _e:
                log.exception(f"[LOOP] Erro: {_e}")
                ERROS_GLOBAIS['loop_crash'] += 1
                time.sleep(1)

    # ---- Getters para o dashboard ----

    def get_rtd_health(self):
        agora = time.time()
        now = datetime.now()
        hm = (now.hour, now.minute)
        pre_abertura = (8, 45) <= hm < (9, 0)
        resultado = {}
        for sym, estado in self.estados.items():
            tempo_sem_neg = agora - estado.ultimo_neg_tempo
            tempo_sem_book = agora - estado.ultimo_book_tempo
            if pre_abertura:
                sem_dados = tempo_sem_book > 30
            else:
                sem_dados = tempo_sem_neg > 15 and tempo_sem_book > 15
            resultado[sym] = {
                'tempo_sem_trade': round(tempo_sem_neg),
                'tempo_sem_book': round(tempo_sem_book),
                'sem_dados': sem_dados,
                'neg_detectados': estado.neg_detectados,
            }
        resultado['_conexao_ok'] = self._conexao_ok
        resultado['_pre_abertura'] = pre_abertura
        return resultado

    def get_contexto_mercado(self):
        resultado = {}
        for sym in list(self.estados.keys()):
            entry = {}
            if self.scorer and hasattr(self.scorer, 'vwaps') and sym in self.scorer.vwaps:
                entry.update(self.scorer.vwaps[sym].snapshot())
            if self.scorer and hasattr(self.scorer, 'ajuste_anterior_oficial'):
                adj = self.scorer.ajuste_anterior_oficial.get(sym)
                entry['ajuste_anterior_oficial'] = adj
                if adj is not None and not (isinstance(adj, float) and (adj != adj)):
                    preco_ult = getattr(self.estados[sym], 'preco_ultimo', 0)
                    if preco_ult > 0:
                        entry['dist_ajuste_oficial_pts'] = preco_ult - adj
                        entry['acima_ajuste_oficial'] = float(preco_ult > adj)
                        entry['abaixo_ajuste_oficial'] = float(preco_ult < adj)
            if hasattr(self.estados[sym], 'preco_ultimo'):
                entry['preco_ultimo'] = self.estados[sym].preco_ultimo
            resultado[sym] = entry
        return resultado

    # ---- Propriedades para compatibilidade com DashboardAPI ----

    @property
    def analise(self):
        """Compatibilidade: delega para self (DashboardAPI usa app.analise.*)."""
        return _AnaliseShim(self)

    def html(self):
        """HTML legado (fallback se dashboard_pro.html não existir)."""
        return '<html><body><h1>Motor v10.0</h1><p>Dashboard em dashboard_pro.html</p></body></html>'

    # ---- Shutdown ----

    def salvar_sessao(self, final=False):
        self.persistence.salvar_sessao(
            final=final,
            salvar_aprendizado=self.learning.salvar,
            padroes=self.market_state.padroes,
        )
        if self.captura:
            self.captura.flush()
            if final:
                self.captura.fechar()

    def _verificar_staleness_reconexao(self, cooldown_segundos=30):
        """Verifica staleness por ativo e reconecta se necessário.

        Restrito ao pregão contínuo (seg-sex 8:45-18:30) com cooldown.

        Returns:
            True se reconectou, False caso contrário
        """
        import time as _time

        # Sem conexão ativa — não faz nada
        if not getattr(self, '_conexao_ok', False):
            return False

        agora = _time.time()
        agora_dt = datetime.now()

        # Fora do pregão (seg-sex 8:45-18:30)
        if agora_dt.weekday() >= 5:  # sábado/domingo
            return False
        hora = agora_dt.hour
        if not (8 <= hora < 18) or (hora == 8 and agora_dt.minute < 45):
            if hora == 18 and agora_dt.minute > 30:
                return False
            if not (8 <= hora < 18):
                return False

        # Cooldown entre reconexões
        ultima = getattr(self, '_ultima_reconexao', 0.0)
        if agora - ultima < cooldown_segundos:
            return False

        # Verifica staleness por ativo
        pre_abertura = hora < 9 or (hora == 9 and agora_dt.minute < 0)

        estados = getattr(self, 'estados', {})
        tem_sem_dados = False
        for _ativo, est in estados.items():
            if _sem_dados_por_ativo(est, agora, pre_abertura=pre_abertura):
                tem_sem_dados = True
                break

        if tem_sem_dados:
            self._ultima_reconexao = agora
            self._reconectar()
            return True

        return False

    def parar(self):
        self._shutdown.set()
        self.salvar_sessao(final=True)
        log.info('[APP] Shutdown completo')


class _AnaliseShim:
    """Shim para compatibilidade com DashboardAPI que usa app.analise.*."""

    def __init__(self, app):
        self._app = app

    @property
    def features(self):
        return self._app.signal.features

    @property
    def sinais(self):
        return self._app.signal.sinais

    @property
    def posicao(self):
        return self._app.position.posicao

    @property
    def stats(self):
        return self._app.market_state.stats

    @property
    def trackers(self):
        return self._app.market_state.trackers

    @property
    def padroes(self):
        return self._app.market_state.padroes

    @property
    def scorer(self):
        return self._app.scorer

    def get_features(self):
        return self._app.signal.get_features()

    def get_sinais(self):
        return self._app.signal.get_sinais()

    def get_posicao(self):
        return self._app.position.get_posicao(
            lambda ativo: self._app.market_state.obter_ultimo_preco(ativo, self._app.signal.features))

    def get_estatisticas(self):
        return self._app.metrics.get_estatisticas()

    def get_memoria(self):
        return self._app.market_state.get_memoria(
            circuit_breaker_nivel=self._app.risk.circuit_breaker_nivel,
            trades_dia=self._app.risk.trades_dia,
            pnl_dia=self._app.risk.pnl_dia,
            perdas_consecutivas=self._app.risk.perdas_consecutivas,
            confianca_ewma=self._app.position.confianca_ewma,
            sinal_confirmado=self._app.position.sinal_confirmado,
        )

    def get_book_stats(self):
        return self._app.market_state.get_book_stats()

    def get_book_level(self):
        return self._app.market_state.get_book_level()

    def calcular_metricas(self):
        return self._app.metrics.calcular()

    def get_resumo(self, ativo):
        return self._app.market_state.get_resumo(ativo)

    def get_saldo_corretoras(self, ativo=None):
        return self._app.market_state.get_saldo_corretoras(ativo)

    def get_historico(self, segundos=1800):
        return self._app.market_state.get_historico(segundos)


# ============================
# Funções auxiliares de staleness (para compatibilidade de testes)
# ============================
def _sem_dados_por_ativo(est, agora, pre_abertura=False):
    """Verifica se um ativo está sem dados (negócios e book parados).

    Args:
        est: estado do ativo (ultimo_neg_tempo, ultimo_book_tempo, neg_detectados)
        agora: timestamp atual
        pre_abertura: True se estamos no pré-leilão (só book conta)

    Returns:
        True se sem dados por > 30s (pregão) ou > 30s book (pré-abertura)
    """
    tempo_sem_neg = agora - est.ultimo_neg_tempo
    tempo_sem_book = agora - est.ultimo_book_tempo

    if pre_abertura:
        # No pré-leilão só o book importa
        return tempo_sem_book > 30

    # Pregão: book parado > 30s OU ambos parados > 15s
    sem_book = tempo_sem_book > 30
    sem_neg = tempo_sem_neg > 15 and tempo_sem_book > 15
    return sem_book or sem_neg

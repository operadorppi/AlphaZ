# -*- coding: utf-8 -*-
"""
core/position_manager.py — Gestão de posições abertas.

Extrai de Analise:
  - gerenciar_posicao (linha 2755)
  - _checar_saidas (linha 2671)
  - _fechar_posicao (linha 2825)
  - _suavizar_sinal (linha 2625)
  - verificar_saidas_tempo_real (linha 2615)
"""

import time
import logging
from datetime import datetime

from core.risk_manager import custo_execucao, horario_permite_abrir

log = logging.getLogger(__name__)


class PositionManager:
    """Gere posições abertas. Não decide sinais nem risco."""

    def __init__(self, risk_manager, persistence=None, learning=None,
                 config=None, ativo_principal='WINV26'):
        self.risk = risk_manager
        self.persistence = persistence
        self.learning = learning
        self.config = config or {}
        self.ativo_principal = ativo_principal
        self.posicao = None

        # Estado de sinal
        self.sinal_confirmado = 0
        self._score_confirmado = 0.0
        self._sinal_streak = 0
        self._sinal_anterior_bruto = 0
        self._lado_anterior = 0
        self.sinal_contador = 0
        self.confianca_ewma = 0.0

    def suavizar(self, lado_bruto, confirmacao_necessaria=None):
        """Suavização de sinal com confirmação por N segmentos."""
        if lado_bruto == 0:
            return self.sinal_confirmado
        if lado_bruto == self._lado_anterior:
            self.sinal_contador += 1
        else:
            self._lado_anterior = lado_bruto
            self.sinal_contador = 1

        conf_alvo = confirmacao_necessaria or self.config.get('confirmacao_necessaria', 3)
        if self.sinal_contador >= conf_alvo:
            self.sinal_confirmado = lado_bruto
            self._score_confirmado = getattr(self, '_score_anterior', 0.0)

        if lado_bruto == self.sinal_confirmado:
            return lado_bruto
        return self.sinal_confirmado if self.sinal_confirmado != 0 else 0

    def gerenciar(self, ativo, sinal_bruto, preco, tp, sl, motivos, contrib,
                  regime=None, limiar_confirmacao=None,
                  cooldown_entre_trades_s=None, max_holding_s=None):
        """Decide abrir/manter/fechar baseado no sinal + estado atual."""
        if ativo != self.ativo_principal:
            return {'acao': 'CONTEXT_ONLY'}

        lado = self.suavizar(sinal_bruto,
                             confirmacao_necessaria=self.config.get('confirmacao_necessaria', 3))
        limiar = limiar_confirmacao if limiar_confirmacao is not None else self.config.get('limiar_confirmacao', 0.55)
        sinal_valido = (lado != 0 and abs(self.confianca_ewma) >= limiar)

        if self.posicao is not None:
            resultado = self.checar_saidas(preco, max_holding_s=max_holding_s)
            return resultado if resultado is not None else {'acao': 'MANTER'}

        if sinal_valido and preco > 0 and self._sinal_streak >= 2:
            pode, motivo = self.risk.pode_abrir(ativo, self.learning.resultados if self.learning else [])
            if not pode:
                return {'acao': motivo}

            l = 'C' if lado > 0 else 'V'
            stop_preco = (preco - sl) if l == 'C' else (preco + sl)

            if self.learning:
                self.learning.previsoes.append({
                    'idx': len(self.learning.previsoes), 'ativo': ativo, 'lado': l,
                    'entrada': preco, 'tp': tp, 'sl': sl,
                    'aberta_em': time.time()
                })

            # Position sizing
            sl_points = abs(preco - stop_preco)
            ps_config = self.config.get('position_sizing', {})
            target_risk = ps_config.get('target_risk_per_trade', 100)
            max_qty = ps_config.get('max_position_size', 5)
            if sl_points > 0:
                quantidade = max(1, min(max_qty, round(target_risk / sl_points)))
            else:
                quantidade = 1

            self.posicao = {
                'ativo': ativo, 'lado': l, 'entrada': preco, 'preco_medio': preco,
                'stop_preco': stop_preco, 'tp': tp,
                'aberta_em': time.time(), 'motivos': list(motivos), 'contrib': list(contrib),
                'prev_idx': len(self.learning.previsoes) - 1 if self.learning else 0,
                'mfe': 0.0, 'mae': 0.0, 'breakeven_ativado': False,
                'regime_abertura': regime or 'indefinido',
                'quantidade': quantidade
            }
            self.risk.trades_dia += 1
            if self.persistence:
                self.persistence.salvar_checkpoint(self.posicao)
            return {'acao': 'ABRIU'}

        return {'acao': 'AGUARDE'}

    def checar_saidas(self, preco, max_holding_s=None):
        """Verifica TP/SL/reversão em tempo real."""
        pos = self.posicao
        if pos is None:
            return None
        lado = pos['lado']
        raw_pnl = (preco - pos['preco_medio']) if lado == 'C' else (pos['preco_medio'] - preco)
        leveraged_pnl = raw_pnl * pos.get('quantidade', 1)
        pos['mfe'] = max(pos.get('mfe', 0), raw_pnl)
        pos['mae'] = min(pos.get('mae', 0), raw_pnl)

        agora = datetime.now()
        fechamento = self.config.get('horario_fechamento', (16, 30))
        if isinstance(fechamento, (list, tuple)):
            fech_t = fechamento[0] * 60 + fechamento[1]
        else:
            fech_t = fechamento
        if self.config.get('desligar_horarios_ruins', True) and (agora.hour, agora.minute) >= (fech_t // 60, fech_t % 60):
            return self._fechar(preco, 'FECHAMENTO_HORARIO')

        max_hold = max_holding_s if max_holding_s is not None else self.config.get('tempo_max_posicao_s', 300)
        if max_hold > 0 and time.time() - pos['aberta_em'] >= max_hold:
            return self._fechar(preco, 'TIMEOUT')

        # REVERSAO
        if self.config.get('reversao_fecha', True) and self.sinal_confirmado != 0:
            holding = time.time() - pos['aberta_em']
            min_hold_rev = self.config.get('min_holding_reversao_s', 90)
            conf_min_rev = self.config.get('confianca_min_reversao', 0.75)
            if holding >= min_hold_rev:
                sinal_lado = 1 if self.sinal_confirmado > 0 else -1
                pos_lado = 1 if pos['lado'] == 'C' else -1
                if sinal_lado != pos_lado and abs(self.confianca_ewma) >= conf_min_rev and abs(self._score_confirmado) > 0.4:
                    return self._fechar(preco, 'REVERSAO')

        # Breakeven
        if self.config.get('usar_breakeven', True) and not pos.get('breakeven_ativado') and leveraged_pnl >= pos['tp'] * 0.5:
            pos['breakeven_ativado'] = True
            pos['stop_preco'] = pos['preco_medio']

        # Trailing
        if self.config.get('usar_trailing', True) and leveraged_pnl >= pos['tp'] * 0.7:
            trail_dist = pos['tp'] * 0.3
            if lado == 'C':
                novo_stop = preco - trail_dist
                if novo_stop > pos.get('stop_preco', 0):
                    pos['stop_preco'] = novo_stop
            else:
                novo_stop = preco + trail_dist
                if pos.get('stop_preco', 9e18) > 0 and novo_stop < pos.get('stop_preco', 9e18):
                    pos['stop_preco'] = novo_stop

        # TP
        if (lado == 'C' and preco >= pos['entrada'] + pos['tp']) or (lado == 'V' and preco <= pos['entrada'] - pos['tp']):
            return self._fechar(preco, 'TP')

        # SL
        if pos.get('stop_preco') and pos['stop_preco'] > 0:
            if lado == 'C' and preco <= pos['stop_preco']:
                return self._fechar(preco, 'SL')
            if lado == 'V' and preco >= pos['stop_preco']:
                return self._fechar(preco, 'SL')

        return None

    def _fechar(self, preco, motivo):
        """Fecha posição e registra resultado."""
        pos = self.posicao
        if pos is None:
            return {'acao': 'SEM_POSICAO'}
        lado = pos['lado']
        raw_pnl = (preco - pos['preco_medio']) if lado == 'C' else (pos['preco_medio'] - preco)
        leveraged_pnl = raw_pnl * pos.get('quantidade', 1)
        acertou = leveraged_pnl > 0

        if self.learning:
            self.learning.resultados.append({
                'idx': pos.get('prev_idx', 0), 'preco_antes': pos['entrada'],
                'preco_depois': preco, 'acertou': acertou, 'delta': leveraged_pnl,
                'lado': lado, 'mfe': pos.get('mfe', 0), 'mae': pos.get('mae', 0), 'motivo': motivo,
                'ts': datetime.now().isoformat(timespec='seconds'),
                'fechada_em': time.time(),
            })
            self.learning.aprender_mfe_mae(pos.get('contrib', []), acertou,
                                          pos.get('mfe', 0), pos.get('mae', 0),
                                          regime_abertura=pos.get('regime_abertura'))

        self.risk.registrar_resultado(leveraged_pnl, acertou, pos.get('ativo', self.ativo_principal))

        self.posicao = None
        self.confianca_ewma = 0.0
        self.sinal_confirmado = 0
        self._lado_anterior = 0
        self.sinal_contador = 0
        if self.persistence:
            self.persistence.salvar_checkpoint(None)
        return {'acao': 'FECHOU', 'pnl': leveraged_pnl, 'motivo': motivo}

    def get_posicao(self, ultimo_preco_fn=None):
        """Retorna posição atual com PnL em tempo real."""
        if self.posicao is None:
            return None
        pos = self.posicao
        preco = ultimo_preco_fn(pos['ativo']) if ultimo_preco_fn else 0
        raw_pnl = (preco - pos['preco_medio']) if pos['lado'] == 'C' else (pos['preco_medio'] - preco)
        leveraged_pnl = raw_pnl * pos.get('quantidade', 1)
        sl_abs = pos.get('stop_preco', 0)
        sl_offset = abs(sl_abs - pos['preco_medio']) if sl_abs > 0 else pos['tp']
        return {
            'lado': pos['lado'], 'entrada': pos['entrada'], 'preco_atual': preco,
            'pnl': leveraged_pnl, 'tp': pos['tp'], 'sl': sl_offset,
            'mfe': pos.get('mfe', 0), 'mae': pos.get('mae', 0),
            'duracao_s': time.time() - pos['aberta_em'],
        }

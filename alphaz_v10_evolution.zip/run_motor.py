#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_motor.py — Entry point unificado do motor (v10.0).

A partir da v10.0, este arquivo usa core/app.py (orquestrador em camadas).
O motor_rt_alphaz.py original foi arquivado para docs/archive/.

Uso:
  python run_motor.py
  python run_motor.py WINV26 WDOU26

Watchdog e Task Scheduler apontam para este arquivo.
"""
import sys
import os
import signal

# Garante que a raiz do projeto está no path
_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from core.app import App

if __name__ == "__main__":
    app = App()
    signal.signal(signal.SIGINT, lambda s, f: app.parar())
    signal.signal(signal.SIGTERM, lambda s, f: app.parar())
    app.run()

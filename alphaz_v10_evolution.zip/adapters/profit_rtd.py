# -*- coding: utf-8 -*-
"""
adapters/profit_rtd.py — Adaptador para conexão COM com ProfitChart RTD.

Extrai de motor_web.py:
  - Conexão COM (_connect, _refresh, _criar_callback, conectar_servidor)
  - Parsing RTD (parse_dat, parse_refresh_data, _normalizar_simbolo)
  - Descoberta de ativos (descobrir_ativos_rtd, preparar_ativos)
  - Threads COM (thread_com, _thread_com_ciclo)
  - Escritores Parquet (thread_escritora, thread_escritora_tt)
  - Schemas (enforce_schema, write_parquet_part)
  - Consolidação (consolidar_book_parquet, consolidar_tt_parquet)
  - Dashboard proxy (_DashboardState, _WebDashboardHandler)
  - Diagnóstico (_diag)

Por enquanto é um shim que re-exporta tudo de motor_web.py.
Gradualmente as funções serão movidas fisicamente para cá.
"""

import sys
import os

# Adiciona raiz do projeto ao path
_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _root not in sys.path:
    sys.path.insert(0, _root)

# Re-exporta tudo de motor_web.py
import importlib.util
_spec = importlib.util.spec_from_file_location('motor_web_root',
    os.path.join(_root, 'motor_web.py'))
_mw = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mw)

# Re-exporta todas as funções e classes públicas
for _name in dir(_mw):
    if not _name.startswith('_') or _name in ('_connect', '_refresh', '_criar_callback',
                                                '_thread_com_ciclo', '_diag',
                                                '_carregar_interfaces', '_normalizar_simbolo',
                                                '_parse_hora_manual', '_topico_invalido',
                                                '_is_iterable', '_live_inc', '_live_get',
                                                '_quarentena_arquivo', '_escrever_parquet_atomico',
                                                '_WebDashboardHandler', '_DashboardState',
                                                '_start_web_dashboard', '_stats_dia_atual',
                                                '_stats_path', '_registrar_stat',
                                                '_stat_chave_book', '_registrar_book',
                                                '_stat_chave_tt', '_registrar_tt',
                                                '_ler_stats', '_sha256_arquivo',
                                                '_duckdb_shell'):
        globals()[_name] = getattr(_mw, _name)

# Alias
ProfitRTD = type('ProfitRTD', (), {
    'conectar_servidor': staticmethod(_mw.conectar_servidor),
    'descobrir_ativos_rtd': staticmethod(_mw.descobrir_ativos_rtd),
    'preparar_ativos': staticmethod(_mw.preparar_ativos),
    'thread_com': staticmethod(_mw.thread_com),
    'thread_escritora': staticmethod(_mw.thread_escritora),
    'thread_escritora_tt': staticmethod(_mw.thread_escritora_tt),
    'parse_refresh_data': staticmethod(_mw.parse_refresh_data),
    'parse_dat': staticmethod(_mw.parse_dat),
    'enforce_schema': staticmethod(_mw.enforce_schema),
    'write_parquet_part': staticmethod(_mw.write_parquet_part),
    'consolidar_book_parquet': staticmethod(_mw.consolidar_book_parquet),
    'consolidar_tt_parquet': staticmethod(_mw.consolidar_tt_parquet),
    'fnum': staticmethod(_mw.fnum),
    'sstr': staticmethod(_mw.sstr),
    'agora_br': staticmethod(_mw.agora_br),
    'limpar_pasta': staticmethod(_mw.limpar_pasta),
    '_connect': staticmethod(_mw._connect),
    '_refresh': staticmethod(_mw._refresh),
    '_criar_callback': staticmethod(_mw._criar_callback),
    '_diag': staticmethod(_mw._diag),
    'MAX_JANELAS_RTD': getattr(_mw, 'MAX_JANELAS_RTD', 12),
    'BOOK_FIELDS': getattr(_mw, 'BOOK_FIELDS', ()),
    'LINHAS_TT': getattr(_mw, 'LINHAS_TT', 1000),
    'POLL_S': getattr(_mw, 'POLL_S', 0.02),
    'EVENT_PUMP_S': getattr(_mw, 'EVENT_PUMP_S', 0.005),
})

#!/bin/bash
# Script para sincronizar alterações automaticamente com o GitHub

INTERVALO=10 # Tempo em segundos entre as verificações

echo "Monitor de sincronização iniciado (Cloud -> GitHub)..."

while true; do
  # Verifica se existem mudanças no diretório (excluindo logs e arquivos temporários)
  if [[ -n $(git status -s | grep -v ".log" | grep -v ".tmp") ]]; then
    git add .
    git commit -m "Auto-sync: $(date +'%Y-%m-%d %H:%M:%S')"
    git push origin main
  fi
  sleep $INTERVALO
done